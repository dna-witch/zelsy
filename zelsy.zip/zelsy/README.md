# zelsy
Cute Python app to detect anxiety and help people reach out for support

1. Detecting Anxiety
2. Helping people to reach out
3. Statistic, Background 
4. Evidence to calm people down
5. Personalized  Interface
6. NLP Sentiment Analysis 


## TODO
* Hardware lab 
* Google how to use API 
* Python sentiment analysis 
* Send messages
* What kind of message do you want to send
* Link different platform together